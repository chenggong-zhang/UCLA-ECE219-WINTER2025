# UCLA-ECE219-WINTER2025
## Project 1: End-to-End Pipeline to Classify News Articles

The notebook contains the code to train and run the models, and create graphs shown in the report. The dataset is retrieved from Google Drive, stored in MyDrive/ece219 folder. Simply change the path to where the dataset is stored in your Google Drive, and run the notebook to try it out!

Installation of glove.6B.zip is done through huggingface as the Stanford website is often down.
